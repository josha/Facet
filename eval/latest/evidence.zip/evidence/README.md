# Evidence index

The expanded Astra Medium visual comparison favors Plain consistently on desktop (6/7 states), portrait (6/7), landscape (4/7), and console (Hub and Tutorial, 2/7). Tablet includes all seven states but splits across presentation orders, producing an inconsistent tie. The earlier three-state desktop Facet win is historical. Console visual captures use the Xbox device preset with keyboard-driven selection and GamepadEnabled false. The separate Controller Emulator diagnostic delivered actual events to both games; queue entry used mixed pointer input, Plain moved, and Facet stayed stationary. Its final driving captures have different overlays and are excluded from matched visual judging. All report counts cover selected diagnostics, not complete acceptance. Setup, custody, source and privacy scopes remain unchanged.

- [Five-device reports, judgments, exact image provenance and controller observations](five-device/supplement-provenance.json)
- [Plain diagnostic report](five-device/plain-report.sanitized.json) and [Facet diagnostic report](five-device/facet-report.sanitized.json)
- Visual judgments: [desktop](judging/devices/desktop/judgment.json), [portrait](judging/devices/phone-portrait/judgment.json), [landscape](judging/devices/phone-landscape/judgment.json), [tablet](judging/devices/tablet/judgment.json), [console](judging/devices/console/judgment.json)
- [Controller event-delivery report](controller/report.sanitized.json), [copy receipts](copy-receipts.json), and [archive manifest](manifest.json)
