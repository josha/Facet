# Latest Facet author trace audit

This audit covers the latest completed Facet author on source 107beff5. It reads the public result and completed tool-call events. It does not establish final game quality or complete acceptance; native evaluation and visual judging are separate.

| Measure | Latest Facet |
| --- | ---: |
| Wall time | 1,473.293 s |
| Total tokens | 8,941,988 |
| Cached input | 8,642,560 |
| Uncached input | 254,222 |
| Output | 45,206 |
| Tool calls / reported errors | 186 / 5 |
| Reported tool time | 106.577 s |

Total tokens include cached input and are not billing receipts. Tool time is about 7.2% of wall time; the trace does not support attributing most author time to transport waits.

## Reading and verification

Documentation reads that reference FacetDocs made 9 attempts, including one failed attempt, and returned 127,918 characters. These are transport text characters, including formatting, not token counts. The first batch returned 33,689 characters and the second returned 34,579. Broad initial reading remains substantial.

The author read the skill, main guide, task-flow chapter, HUD recipe and mounting/state cards in the first batch. It read Layout, Input, Tasks.pages and Compose ownership next, then collection-detail and Stage. No explicit read of Tasks.inspect.md appears in the tool arguments. The first task-specific Garage split reference lookup was at about 1,021 seconds; the successful constructor reference followed at 1,069 seconds. A split Garage implementation was written at about 1,144 seconds. These events show which guidance was read, not that every supplied example informed the design.

Three guessed documentation routes returned MISSING: TextField.card, TextField.reference and Slider.reference. The next batch switched to existing TextInput and Stepper-and-Slider routes.

First Play completed at 404.46 seconds and exposed a client syntax error. After correction and restart, the first capture completed at 432.31 seconds. The run used 11 captures, 19 Play/stop calls, 42 console reads and 63 input calls. Capture count alone is not a visual-quality measure.

The trace includes a viewport query and a native Color3:Lerp probe. Input suspension in the written code is derived from current race, route and overlay state. The confirmation overlay was moved to persistent ownership. These are implementation choices visible in tool writes, not a complete final-source or native-lifetime verdict.

## Errors and remaining work cost

The five failed tool calls were:

- 75.61 s: world cleanup attempted to destroy Terrain; the console reported Cannot Destroy() Terrain.
- 443.87 s: a direct input query asserted that a Join queue TextButton existed; it did not match a button.
- 666.90 s: VirtualInput rejected Tab as a reserved CoreGUI key.
- 1,021.63 s: an Edit documentation lookup failed while Play was active. No diagnostic text followed; the lookup later succeeded through Server. The mode mismatch is an inference from that sequence.
- 1,051.37 s: VirtualInput rejected direct ButtonB injection as a reserved CoreGUI key. This does not test the native Controller Emulator's mapped Gamepad1 events.

Successful console-read calls also exposed authored runtime/parse failures: a missing closing parenthesis at 409.28 s, Color3 multiplied by a number in kartModel at 462.24 s, and a malformed number at 576.79 s. These are not included in the tool-error counter. The Color3 error was followed by the native Lerp probe and source rewrites; that early error is not a confirmed defect in the final frozen game.

The run made 13 Source-writing calls whose argument text totaled 528,855 characters. Twelve writes exceeded 10,000 characters. These counts include embedded code and repeated replacement payloads, not net source growth. Literal find(..., true) splices appear. Repeated large Source payloads remain an observable cost. Late writes integrate layout, persistent overlays, audio, touch visibility and track-speed behavior. This suggests scope and integration work remain significant; the trace cannot assign a causal percentage to each concern.

Sources: the latest Facet result.json and transcript.jsonl at run-evidence/runs/run/facet/codex-astra/seed-1 under astra-medium-learning-rerun. Times above are elapsed transcript completion times. No raw session text, private account paths or process identifiers are included. This is a latest-only excerpt of the completed audit; no model, Studio, source-edit or frozen-input operation was performed for it.

## Compact HUD sizing

The frozen client's generic `text` helper sets `wrap = true` (`source-inspection/01-VectorClient.luau:133`). Its compact HUD calls that helper inside a HStack with no width (`:369`). Facet HStack defaults to hug/hug (`src/ui/layout_kit.luau:492`), but wrapped Text gets `Size.X.Scale = 1` and `AutomaticSize.Y` (`src/ui/media_text.luau:205–206`). Thus the child depends on the width of the parent that hugs it. The first portrait native observation placed Menu at X = 800,680 pixels, outside the 389-pixel device viewport (the native JPEG is 498 pixels wide). This is consistent with the circular sizing dependency; no isolated native reproduction proves it caused that exact coordinate.

The new `Tasks.hud` short form uses unwrapped Text. Its defaults are zero-offset Size and `AutomaticSize.XY` (`src/ui/context_content.luau:440–441`), so the recipe itself does not introduce this scale dependency. Region also hugs its forms (`src/ui/composition.luau:102–103,149–150`). This source comparison does not prove all supplied labels fit every viewport. The corrected portrait capture route retains the failed offscreen Menu pointer check and records its keyboard M fallback; it is visual evidence with mixed input, not a touch-navigation pass.
