# Latest Plain and Facet evaluation evidence

This archive supports the most recent Plain and Facet author runs. Its purpose
is to assess first-attempt game UI quality from Facet's skill, design guidance
and controls. Both authors and the judge used gpt-6-astra with medium effort.
Plain retains its original frozen submission. Facet was authored on `107beff5`
with the same brief, acceptance requirements, seed, Studio MCP-only tools and
30-minute limit. No frozen game was repaired during evaluation.

| Device | Matched states | Both-order result |
| --- | ---: | --- |
| Desktop | 7/7 | Facet twice |
| Phone portrait | 6/7 | Plain twice |
| Phone landscape | 6/7 | Plain twice |
| Tablet | 7/7 | Facet twice |
| Console | 6/7 | One win each; order disagreement |

Phone Results is missing because Plain's ACCEL checks failed. Console Results
is missing because Facet's mixed-input route did not reach it. Visual results
are scoped to the listed states, not complete game acceptance.

- `judgments/` holds five byte-identical public judgment files and relative
  provenance for the ten requests, one attempt per order, with no retries.
- `images/` holds all 64 exact JPEG inputs, unchanged. Provenance maps device,
  state and arm to each image, dimensions, hash and presentation order.
- `author/` holds the latest pair's usage, identity and original public results.
  The immediate Facet submission check failed before the full place was sealed;
  the later passing submission check is separate. Original failures remain.
- `native/` holds consolidated capture reports, input events, before/after
  values and route observations. Desktop and three touch presets moved Facet's
  kart. Portrait Menu and tablet HUD Join needed alternative routes. Console
  delivered Gamepad1 plus MouseButton1, reopened Menu, disabled driving and did
  not move. This does not isolate a pure R2 defect or prove controller gameplay.
- `source/` holds findings from the latest Facet transcript and frozen source.
  These identify compact HUD sizing and repeated Source writes as targets;
  they do not establish causation or a future pass.
- `validation/` records 38 passing runnable full-tier source producers, two
  deferrals and two excluded release producers, plus the separate benchmark
  and selected native observations. The standard navigation report passed
  one case with 17 steps. Garage Save was observed on desktop and both phone
  orientations, with desktop save/change/reload also checked.
- `captures/garage-*.jpg` shows source-example checks, separate from generated
  game evidence. `captures/facet-*.jpg` preserves two native failure views.
- `copy-receipts.json` and `judge-copy-receipts.json` record original hashes,
  published hashes and transformations. `manifest.json` lists every payload
  and the external frozen game hashes. It excludes its own hash.

All paths are relative or sanitized. Raw model sessions and private process
identifiers are excluded. Original report failures, mixed input and missing
states remain explicit. Native Studio presets are not physical-device proof;
broad game acceptance and performance overhead remain unverified.
