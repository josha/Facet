# Evidence

- `images/<device>/<arm>/<state>.jpg`: the screenshots the judge compared.
- `judgments/judgments.json`: both presentations of each device comparison, with criteria and reasons.
- `author/<arm>-result.sanitized.json`: run status, usage and hidden check results.
- `comparison.txt`: the comparison report.
- `unreachable-states.txt`: states the checker could not reach with real input.
