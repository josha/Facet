# Evidence

- `images/<device>/<arm>/<state>.jpg`: every screenshot the player scripts captured.
- `judgments/judgments.json`: both presentations of each device comparison, judged on the states both games reached, with criteria and reasons.
- `evaluation/<arm>/player.luau`: the player scripts that drove each game with real input.
- `author/<arm>-result.sanitized.json`: run status, usage and check results.
- `comparison.txt`: the comparison report.
- `unreachable-states.txt`: states the player scripts did not reach, and why.
