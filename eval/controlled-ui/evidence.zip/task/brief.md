# Abyss Relay: the survey interface

Design and implement a distinctive, finished interface for this supplied underwater survey demo. The game is already supplied: its native 3D seabed, survey bell, camera, equipment models, session state and actions. Build only the UI. Keep the supplied game code, models, camera, lighting and behavior unchanged. Do not create replacement game scenes or subject art. You may display the supplied equipment models in previews.

The visual direction is an optimistic deep-sea research expedition: legible instruments, mineral color, deliberate typography and controls with character. The UI should feel made for this expedition. You decide its composition and visual treatments. Explore a concept with the tools you have, then build the key screens. Keep text and interactions live. An image generator, when present in your tools, can create UI assets; upload is available in image-enabled runs. No particular asset count is required.

Provide three connected player tasks:

1. Survey HUD over the supplied game scene. Show the current phase, oxygen, depth, sample progress and selected instrument at a glance. Allow departure, scanning the next sample and surfacing. Keep the survey bell and seabed visible. The game supplies each accepted action and the resulting values.
2. Equipment decisions. Show three supplied instruments with their appearance, capacity and depth rating, current selection, ownership and price. Let the player equip an owned instrument and preview a purchase with Confirm and Cancel. Show an unaffordable instrument truthfully. A cancellation must not spend credits or change equipment. Return to the HUD must remain clear.
3. Expedition report after surfacing. Show the collected sample count, accepted payout, current balance and next step. Returning to base must lead back to a usable HUD and preserve equipment ownership.

Use the supplied API document in ServerStorage.GameApiDocs. The complete initial game fixture is under ReplicatedStorage.SurveyGame, ServerScriptService.SurveyServer, StarterPlayerScripts.SurveyCamera and Workspace.SurveyWorld. These roots are immutable. Put persistent UI code under StarterPlayerScripts.SurveyUI and/or StarterGui; UI helper modules can live in ReplicatedStorage.SurveyUI. Keep supplied libraries and their capability settings unchanged. Check the game in Play; deliver persistent Edit source.

Support desktop 1920x1080, phone portrait 390x844 and phone landscape 844x390. Check the actual rendered text, controls and return paths using pointer, touch simulation and engine selection where available. Keep concept and representative screen captures. Final response: what you built and tested, uploaded UI asset IDs if any, and remaining limitations. Leave Studio open. This is a UI study, not a request to build a full game.
