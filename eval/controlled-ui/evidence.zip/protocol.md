# Controlled UI comparison

Freeze before authors run. This is a key-screen experiment, not the complete-game baseline.

Task: Abyss Relay, a supplied underwater survey demonstration. All authors receive identical game source, models, camera, initial state, actions and outcomes. Authors implement the interface only. No driving, physics, persistence or new world art is requested. Three connected tasks: survey HUD, equipment decisions, expedition result. The supplied scene is a native 3D scene, not generated background art.

Seven fresh authors, each with one uninterrupted 1200-second budget, Sol 6.1 Medium or Opus 5.5 Medium as specified:
- plain-sol: native Roblox, image generation unavailable.
- plain-sol-images: native Roblox, image generation and upload available.
- plain-opus: native Roblox, image generation unavailable.
- facet-before: Sol, Facet guidance from c8ae0b9b80eb91d1cbcf1710cc4775bc25975f84, no image generation.
- facet-before-images: same prior guidance, image generation and upload available.
- facet-after: Sol, merged PR 538 guidance, no image generation.
- facet-after-images: same new guidance, image generation and upload available.

All Facet arms use the same current runtime. All arms use the same evaluator with native activation acknowledgement and safe touch scroll reveal. The prior/new comparison isolates guidance, not evaluator fixes. Common instructions specify task scope, custody and supplied game API, without teaching the new native/image decision rule. Prior and new Facet instructions differ only in frozen skill content. The plain arms have the same task and engine tools without Facet. Image uploads must pass preflight before the author clock starts. No author sees other submissions or receives operator coaching. Internal author self-checks are part of its budget; no post-deadline repairs enter initial scores.

Freeze source hashes, prompts, tool profiles, budgets and game fixture before first author. Retain all transcripts, costs, generated concepts, uploads, persistent submissions and exact tool failures. Hash the supplied game roots after each author; a mutation is a protocol violation, not an improved UI. Restore the same fixture before every run. Back up the existing published study before reusing its upload-capable Studio. Keep each submission separately.

Evaluate desktop 1920x1080, portrait 390x844 and landscape 844x390, recording actual viewport. Exercise pointer, simulated touch and engine keyboard selection separately; do not claim physical controller coverage. Test start, scan, surface/result, return, owned equip, successful purchase, cancellation and unaffordable purchase. Capture matching server states, including selected/focused and confirmation states. Freeze submissions before evaluation. Report unavailable or broken states, never substitute a different state for a favorable comparison.

Judge anonymous matching captures in both orders with the existing Verify judge: player intent, hierarchy, UI identity/craft, readability, protection of the supplied world, adaptation, fit and truthful outcomes. Supplied scene detail earns no UI credit. Primary comparisons: after versus before in each image condition, Facet-after versus plain Sol in each image condition. Plain Opus versus plain Sol is a descriptive model comparison. Screens and devices are repeated observations of one task, not independent trials. One author per arm cannot establish population significance.

Report tool use, visible native/image rationale, concept-to-build losses, UI asset count versus game asset count, functional outcomes, blocking readability/overlap, visual preference and author cost separately. A better screenshot cannot cancel broken interaction. This is a new task, but a single controlled task remains limited evidence.

## Instruction isolation preflight correction

The first two processes are invalid infrastructure pilots, retained under pilots/inherited-context. The plain author attempted to load Facet skills not requested by its prompt. A local prompt-input audit confirmed inherited repository AGENTS.md and the personal skills catalog. The CLI's --ignore-user-config excludes config.toml only. Both pilots were interrupted before scoring; their submissions, usage and logs are retained separately.

All scored Codex runs explicitly use project_doc_max_bytes=0, skills.include_instructions=false, skills.bundled.enabled=false and skip_host_skill_discovery=true. Model-visible context was checked locally: inherited Facet/critique/lean-code instructions disappeared. Frozen arm instructions are still passed directly as developer instructions, and Facet references remain supplied through StudioDocs. Claude retains its project-only settings, disabled auto memory and disabled CLAUDE.md discovery. No task, game fixture, budget or scoring criterion changed. Restart with fresh sessions and the untouched fixture.

Reference: https://learn.chatgpt.com/docs/config-file/config-reference . Local CLI help and profile-before.json/profile-isolated.json are the direct evidence for this installed version.
